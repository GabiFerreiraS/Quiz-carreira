var div1 = document.getElementById("div1");
var div2 = document.getElementById("caixa-principal");
var div3 = document.getElementById("caixa-resultado");
const perguntas = {
  inicial: [
    {
      enunciado: "Qual área da tecnologia mais chama sua atenção?",
      alternativas: [
        {
          texto: "Desenvolvimento de Software",
          proximaArea: "desenvolvimento",
        },
        { texto: "Segurança da Informação", proximaArea: "seguranca" },
        { texto: "Ciência de Dados", proximaArea: "ciencia_dados" },
        { texto: "Design e UX", proximaArea: "design" },
        { texto: "Infraestrutura e Redes", proximaArea: "infraestrutura" },
      ],
    },
  ],
  desenvolvimento: [
    {
      enunciado:
        "Qual linguagem de programação você mais gostaria de aprender?",
      alternativas: ["JavaScript", "Python", "Java", "C#", "Outro"].map(
        (texto) => ({ texto, proxima: null })
      ),
    },
    {
      enunciado: "Você prefere trabalhar com Frontend, Backend ou Fullstack?",
      alternativas: ["Frontend", "Backend", "Fullstack"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Qual framework Frontend você considera mais interessante?",
      alternativas: ["React", "Vue.js", "Angular", "Svelte", "Outro"].map(
        (texto) => ({ texto, proxima: null })
      ),
    },
    {
      enunciado: "Você gostaria de aprender mais sobre bancos de dados?",
      alternativas: ["Sim, SQL", "Sim, NoSQL", "Não tenho certeza", "Não"].map(
        (texto) => ({ texto, proxima: null })
      ),
    },
    {
      enunciado: "Qual prática de desenvolvimento você considera importante?",
      alternativas: [
        "Testes Automatizados",
        "DevOps",
        "Code Reviews",
        "Metodologias Ágeis",
        "Outros",
      ].map((texto) => ({ texto, proxima: null })),
    },
    {
      enunciado: "Você gosta de trabalhar em projetos grandes ou pequenos?",
      alternativas: ["Grandes", "Pequenos", "Ambos"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Você prefere desenvolver aplicativos ou sistemas web?",
      alternativas: ["Aplicativos", "Sistemas Web", "Ambos"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Está interessado em aprender sobre Inteligência Artificial?",
      alternativas: ["Sim", "Talvez", "Não"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Qual editor de código você prefere?",
      alternativas: ["VSCode", "IntelliJ", "Vim", "Outro"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Você gostaria de aprender sobre desenvolvimento mobile?",
      alternativas: ["Sim", "Não", "Talvez"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Prefere trabalhar sozinho ou em equipe?",
      alternativas: ["Sozinho", "Em Equipe", "Depende do projeto"].map(
        (texto) => ({ texto, proxima: null })
      ),
    },
    {
      enunciado: "Qual abordagem de aprendizado você prefere?",
      alternativas: [
        "Cursos Online",
        "Livros",
        "Prática com Projetos",
        "Mentoria",
        "Outros",
      ].map((texto) => ({ texto, proxima: null })),
    },
    {
      enunciado: "Já teve contato com desenvolvimento ágil?",
      alternativas: ["Sim", "Não", "Estou aprendendo"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Você se interessa por engenharia de software?",
      alternativas: ["Sim", "Talvez", "Não"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Gostaria de criar seus próprios projetos?",
      alternativas: ["Sim", "Não", "Depende"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Qual ferramenta de controle de versão você mais utiliza?",
      alternativas: ["Git", "SVN", "Mercurial", "Outros"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
  ],
  seguranca: [
    {
      enunciado: "Qual aspecto de segurança mais te interessa?",
      alternativas: [
        "Testes de Penetração",
        "Forense Digital",
        "Criptografia",
        "Gestão de Riscos",
        "Compliance",
      ].map((texto) => ({ texto, proxima: null })),
    },
    {
      enunciado: "Qual ferramenta você gostaria de aprender?",
      alternativas: [
        "Metasploit",
        "Nmap",
        "Wireshark",
        "Burp Suite",
        "Outra",
      ].map((texto) => ({ texto, proxima: null })),
    },
    {
      enunciado: "Você tem interesse em aprender sobre segurança em nuvem?",
      alternativas: ["Sim", "Não", "Talvez"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Quais protocolos de rede você conhece?",
      alternativas: ["HTTP", "HTTPS", "FTP", "SSH", "Outros"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Qual tipo de ataque você acha mais interessante?",
      alternativas: ["DDoS", "Phishing", "SQL Injection", "XSS", "Outro"].map(
        (texto) => ({ texto, proxima: null })
      ),
    },
    {
      enunciado: "Você já trabalhou com firewalls?",
      alternativas: ["Sim", "Não", "Estou aprendendo"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado:
        "Você prefere trabalhar em análise de vulnerabilidades ou resposta a incidentes?",
      alternativas: [
        "Análise de Vulnerabilidades",
        "Resposta a Incidentes",
        "Ambos",
      ].map((texto) => ({ texto, proxima: null })),
    },
    {
      enunciado: "Qual sua experiência com criptografia?",
      alternativas: ["Experiente", "Intermediário", "Iniciante", "Nenhuma"].map(
        (texto) => ({ texto, proxima: null })
      ),
    },
    {
      enunciado: "Você tem interesse em certificações de segurança?",
      alternativas: ["Sim", "Não", "Talvez"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Qual é a sua abordagem preferida para estudar segurança?",
      alternativas: [
        "Cursos Online",
        "Prática com Laboratórios",
        "Livros",
        "Mentoria",
        "Outros",
      ].map((texto) => ({ texto, proxima: null })),
    },
    {
      enunciado: "Você já trabalhou em auditoria de segurança?",
      alternativas: ["Sim", "Não", "Estou aprendendo"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Você conhece as normas ISO de segurança?",
      alternativas: ["Sim", "Não", "Ouvi falar"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Qual é a sua experiência com gestão de riscos?",
      alternativas: ["Experiente", "Intermediário", "Iniciante", "Nenhuma"].map(
        (texto) => ({ texto, proxima: null })
      ),
    },
    {
      enunciado: "Qual tipo de análise você prefere?",
      alternativas: [
        "Análise de Malware",
        "Análise de Vulnerabilidades",
        "Análise de Logs",
        "Análise de Tráfego",
      ].map((texto) => ({ texto, proxima: null })),
    },
    {
      enunciado: "Qual é o seu nível de conhecimento sobre firewalls?",
      alternativas: ["Avançado", "Intermediário", "Iniciante", "Nenhum"].map(
        (texto) => ({ texto, proxima: null })
      ),
    },
    {
      enunciado: "Você já participou de algum CTF de segurança?",
      alternativas: ["Sim", "Não", "Estou interessado"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Você prefere trabalhar com segurança ofensiva ou defensiva?",
      alternativas: ["Ofensiva", "Defensiva", "Ambos"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
  ],
  ciencia_dados: [
    {
      enunciado: "Você gosta de trabalhar com dados?",
      alternativas: ["Sim", "Não", "Talvez"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Já teve contato com Python para análise de dados?",
      alternativas: ["Sim", "Não"].map((texto) => ({ texto, proxima: null })),
    },
    {
      enunciado: "Qual ferramenta de visualização de dados você prefere?",
      alternativas: ["Tableau", "Power BI", "Google Data Studio", "Outros"].map(
        (texto) => ({ texto, proxima: null })
      ),
    },
    {
      enunciado: "Qual é a sua experiência com machine learning?",
      alternativas: ["Avançada", "Intermediária", "Iniciante", "Nenhuma"].map(
        (texto) => ({ texto, proxima: null })
      ),
    },
    {
      enunciado: "Qual é a sua abordagem preferida para análise de dados?",
      alternativas: [
        "Análise Estatística",
        "Análise Preditiva",
        "Análise Descritiva",
        "Outros",
      ].map((texto) => ({ texto, proxima: null })),
    },
    {
      enunciado: "Você já trabalhou com big data?",
      alternativas: ["Sim", "Não", "Estou aprendendo"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Qual é a sua linguagem preferida para análise de dados?",
      alternativas: ["Python", "R", "SQL", "Outro"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Você gosta de trabalhar com algoritmos de machine learning?",
      alternativas: ["Sim", "Não", "Talvez"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Qual é a sua experiência com estatísticas?",
      alternativas: ["Avançada", "Intermediária", "Iniciante", "Nenhuma"].map(
        (texto) => ({ texto, proxima: null })
      ),
    },
    {
      enunciado:
        "Você prefere trabalhar com dados estruturados ou não estruturados?",
      alternativas: ["Estruturados", "Não estruturados", "Ambos"].map(
        (texto) => ({ texto, proxima: null })
      ),
    },
    {
      enunciado: "Você já trabalhou com algum projeto de análise de dados?",
      alternativas: ["Sim", "Não", "Estou começando"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Qual é a sua familiaridade com bases de dados SQL?",
      alternativas: ["Avançada", "Intermediária", "Iniciante", "Nenhuma"].map(
        (texto) => ({ texto, proxima: null })
      ),
    },
    {
      enunciado: "Você se interessa por data storytelling?",
      alternativas: ["Sim", "Não", "Talvez"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado:
        "Você já trabalhou com processamento de dados em larga escala?",
      alternativas: ["Sim", "Não", "Estou aprendendo"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Você prefere projetos de análise preditiva ou descritiva?",
      alternativas: ["Preditiva", "Descritiva", "Ambos"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Você conhece e usa bibliotecas como pandas e scikit-learn?",
      alternativas: ["Sim", "Não", "Estou aprendendo"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
  ],
  design: [
    {
      enunciado: "Qual aspecto do design você mais gosta?",
      alternativas: ["UI", "UX", "Design Gráfico", "Outros"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Você já trabalhou com prototipagem?",
      alternativas: ["Sim", "Não", "Estou aprendendo"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Qual ferramenta de design você mais gosta de usar?",
      alternativas: ["Figma", "Adobe XD", "Sketch", "Outras"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Qual é a sua experiência com pesquisa de usuários?",
      alternativas: ["Avançada", "Intermediária", "Iniciante", "Nenhuma"].map(
        (texto) => ({ texto, proxima: null })
      ),
    },
    {
      enunciado: "Qual é a sua abordagem de desenvolvimento de protótipos?",
      alternativas: ["Low-fidelity", "High-fidelity", "Ambos"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Você tem interesse em aprender sobre design responsivo?",
      alternativas: ["Sim", "Não", "Talvez"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Qual é a sua abordagem para manter a consistência visual?",
      alternativas: ["Uso de componentes", "Guia de estilo", "Outro"].map(
        (texto) => ({ texto, proxima: null })
      ),
    },
    {
      enunciado: "Você já trabalhou com design inclusivo?",
      alternativas: ["Sim", "Não", "Estou aprendendo"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Você gosta de trabalhar com animações e transições?",
      alternativas: ["Sim", "Não", "Talvez"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Qual é a sua experiência com análise de métricas de usuário?",
      alternativas: ["Avançada", "Intermediária", "Iniciante", "Nenhuma"].map(
        (texto) => ({ texto, proxima: null })
      ),
    },
    {
      enunciado: "Qual é o seu nível de conhecimento em acessibilidade?",
      alternativas: ["Avançado", "Intermediário", "Iniciante", "Nenhum"].map(
        (texto) => ({ texto, proxima: null })
      ),
    },
    {
      enunciado: "Você já participou de projetos colaborativos de design?",
      alternativas: ["Sim", "Não", "Estou aprendendo"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado:
        "Você prefere trabalhar em projetos de design visual ou interação?",
      alternativas: ["Visual", "Interação", "Ambos"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Qual ferramenta de prototipagem você prefere?",
      alternativas: ["Figma", "Adobe XD", "Sketch", "Outras"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
  ],
  infraestrutura: [
    {
      enunciado: "Qual aspecto de infraestrutura mais te interessa?",
      alternativas: [
        "Redes",
        "Servidores",
        "Cloud",
        "Virtualização",
        "Outros",
      ].map((texto) => ({ texto, proxima: null })),
    },
    {
      enunciado: "Qual ferramenta de gerenciamento você prefere?",
      alternativas: ["Ansible", "Terraform", "Docker Compose", "Outros"].map(
        (texto) => ({ texto, proxima: null })
      ),
    },
    {
      enunciado: "Você já trabalhou com containers?",
      alternativas: ["Sim", "Não", "Estou aprendendo"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Qual é a sua experiência com ambientes em nuvem?",
      alternativas: ["Avançada", "Intermediária", "Iniciante", "Nenhuma"].map(
        (texto) => ({ texto, proxima: null })
      ),
    },
    {
      enunciado:
        "Você tem interesse em aprender sobre orquestração de containers?",
      alternativas: ["Sim", "Não", "Talvez"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Qual é a sua experiência com redes e protocolos?",
      alternativas: ["Avançada", "Intermediária", "Iniciante", "Nenhuma"].map(
        (texto) => ({ texto, proxima: null })
      ),
    },
    {
      enunciado: "Você prefere trabalhar com sistemas Windows, Linux ou ambos?",
      alternativas: ["Windows", "Linux", "Ambos"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Você já trabalhou com configurações de servidores?",
      alternativas: ["Sim", "Não", "Estou aprendendo"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Qual é a sua familiaridade com CI/CD?",
      alternativas: ["Alta", "Média", "Baixa", "Nenhuma"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Você já trabalhou com ambientes de virtualização?",
      alternativas: ["Sim", "Não", "Estou aprendendo"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Qual é a sua experiência com monitoramento de sistemas?",
      alternativas: ["Avançada", "Intermediária", "Iniciante", "Nenhuma"].map(
        (texto) => ({ texto, proxima: null })
      ),
    },
    {
      enunciado: "Você prefere trabalhar com servidores físicos ou virtuais?",
      alternativas: ["Físicos", "Virtuais", "Ambos"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Você já trabalhou com armazenamento em nuvem?",
      alternativas: ["Sim", "Não", "Estou aprendendo"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado:
        "Qual ferramenta de gerenciamento de configuração você prefere?",
      alternativas: ["Ansible", "Puppet", "Chef", "Outros"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
    {
      enunciado: "Você gosta de aprender sobre novas tecnologias de rede?",
      alternativas: ["Sim", "Não", "Talvez"].map((texto) => ({
        texto,
        proxima: null,
      })),
    },
  ],
};

const conclusao = {
  desenvolvimento:
    "Você parece interessado em desenvolvimento de software! Explore linguagens como JavaScript, Python, ou frameworks como React e Node.js.",
  seguranca:
    "Segurança da Informação é essencial! Considere aprender sobre criptografia, forense digital e ferramentas como Metasploit e Wireshark.",
  ciencia_dados:
    "Ciência de Dados oferece oportunidades incríveis! Explore Machine Learning, Big Data e ferramentas como Python e Tableau.",
  design:
    "Design e UX são áreas criativas! Estude ferramentas como Figma e Adobe XD, além de boas práticas em acessibilidade digital.",
  infraestrutura:
    "Infraestrutura é desafiadora e vital! Explore redes, virtualização, e computação em nuvem com Docker e Kubernetes.",
};

// Variáveis de controle do quiz
let currentArea = "";
let currentQuestionIndex = 0;

document.getElementById("startButton").addEventListener("click", function () {
  iniciarQuiz();
});
//////////////////////////////////////////////////////

function iniciarQuiz() {
  // Inicializa a área inicSial e começa o quiz com a primeira pergunta

  currentArea = "inicial";
  currentQuestionIndex = 0;
  div1.style.display = "none";
  div2.style.display = "block";
  renderQuestion();
}
//////////////////////////////////////////////////////////
function renderQuestion() {
  const currentQuestion = perguntas[currentArea][currentQuestionIndex];

  // Exibe a pergunta na tela
  const perguntaDiv = document.querySelector(".caixa-perguntas");
  perguntaDiv.innerHTML = `<h2>${currentQuestion.enunciado}</h2>`;

  // Limpa e renderiza as alternativas
  const alternativasDiv = document.querySelector(".caixa-alternativas");
  alternativasDiv.innerHTML = ""; // Limpa alternativas antigas

  currentQuestion.alternativas.forEach((alternativa, index) => {
    const alternativaElemento = document.createElement("button");
    alternativaElemento.textContent = `${index + 1}: ${alternativa.texto}`;
    alternativaElemento.classList.add("alternativa-btn");
    alternativaElemento.onclick = () => {
      handleAnswerSelection(index);
    };
    alternativasDiv.appendChild(alternativaElemento);
  });
}
/////////////////////////////////////////////////////////
function continuarQuiz() {
  if (currentQuestionIndex < perguntas[currentArea].length - 1) {
    currentQuestionIndex++;
    renderQuestion();
  } else {
    console.log("Você terminou todas as perguntas desta seção.");
    alert("Seção concluída!");
    exibirConclusao(currentArea);
  }
}
///////////////////////////////////////////////////////
function handleAnswerSelection(selectedIndex) {
  console.log("Área atual antes da seleção:", currentArea);
  const currentQuestion = perguntas[currentArea][currentQuestionIndex]; // Obtém a pergunta atual
  const selectedAnswer = currentQuestion.alternativas[selectedIndex]; // Alternativa escolhida

  console.log(`Você selecionou a alternativa: ${selectedAnswer.texto}`);

  // Verifica se a alternativa selecionada deve levar a outra área
  if (selectedAnswer.texto === "Design e UX") {
    // 'nextArea' indica a próxima área, caso exista
    currentArea = "design"; // Atualiza a área atual
    currentQuestionIndex = 0; // Reinicia o índice das perguntas na nova área
    console.log("Área atual após a mudança:", currentArea);
    renderQuestion(); // Renderiza a primeira pergunta da nova área
  }
  if (selectedAnswer.texto === "Desenvolvimento de Software") {
    currentArea = "desenvolvimento"; // Atualiza a área atual
    currentQuestionIndex = 0; // Reinicia o índice das perguntas na nova área
    console.log("Área atual após a mudança:", currentArea);
    renderQuestion(); // Renderiza a primeira pergunta da nova área
  }
  if (selectedAnswer.texto === "Segurança da Informação") {
    currentArea = "seguranca"; // Atualiza a área atual
    currentQuestionIndex = 0; // Reinicia o índice das perguntas na nova área
    console.log("Área atual após a mudança:", currentArea);
    renderQuestion(); // Renderiza a primeira pergunta da nova área
  }
  if (selectedAnswer.texto === "Ciência de Dados") {
    currentArea = "ciencia_dados"; // Atualiza a área atual
    currentQuestionIndex = 0; // Reinicia o índice das perguntas na nova área
    console.log("Área atual após a mudança:", currentArea);
    renderQuestion(); // Renderiza a primeira pergunta da nova área
  }
  if (selectedAnswer.texto === "Infraestrutura e Redes") {
    currentArea = "infraestrutura"; // Atualiza a área atual
    currentQuestionIndex = 0; // Reinicia o índice das perguntas na nova área
    console.log("Área atual após a mudança:", currentArea);
    renderQuestion(); // Renderiza a primeira pergunta da nova área
  } else {
    continuarQuiz(); // Continua com as perguntas na mesma área
  }
}
///////////////////////////////////////////////
function exibirConclusao(currentArea) {
  div2.style.display = "none";
  div3.style.display = "block";

  const conclusaoMessage = conclusao[currentArea];
  console.log(conclusaoMessage);
  const resposta = document.querySelector(".texto-resultado");
  console.log("teste final: ", resposta);
  resposta.innerHTML = `<h2>${conclusaoMessage}</h2>`;
}
